#define _XTAL_FREQ 125000  // ???????__delay_ms() ??

#include "setting_hardaware/setting.h"
#include <stdlib.h>
#include "stdio.h"
#include "string.h"
// using namespace std;
#include <xc.h>
volatile unsigned char targetLampState = 0;  // ??????
volatile unsigned char currentLampState = 0; // ??????
volatile unsigned char isCalculating = 0;    // ?????????
char str[20];
void main(void) 
{
    OSCCONbits.IRCF = 0b111;
    
    INTCON2bits.INTEDG0 = 0;  // ????????
    INTCONbits.INT0IF = 0;  // ??????0???
    INTCONbits.GIE = 1;     // ??????
    INTCONbits.INT0IE = 1;  // ??????0 (RB0 ????)
    
    SYSTEM_Initialize() ;
    TRISA=0x00;
    PORTA=0x00;
    TRISB=0x01;
    PORTB=0x00;
    while(1){
        strcpy(str, GetString()); // TODO : GetString() in uart.c
        if (isCalculating && currentLampState < targetLampState) {
            __delay_ms(10000);  // ????????
            LATA = currentLampState;
            currentLampState++;
            
            if (currentLampState >= targetLampState) {
                isCalculating = 0;
                LATA = targetLampState - 1;
            }
        }
    }
    return;
}
void numcount(unsigned char num);
void __interrupt(high_priority) Hi_ISR(void)
{
    
}
// void interrupt low_priority Lo_ISR(void)
void __interrupt(low_priority)  Lo_ISR(void)
{
    if (PIR1bits.RCIF) {                    
        char received = RCREG;              
        
        if (received >= '0' && received <= '9') { 
            unsigned char newDigit = received - '0';
            
            if (isCalculating) {
                // ??????????????????
                currentLampState = 0;
                targetLampState = newDigit + 1;
                isCalculating = 1;
            } else {
                // ???????
                targetLampState = newDigit + 1;
                isCalculating = 1;
                currentLampState = 0;
                LATA = 0x00;
            }
            
            UART_Write(received);
        }
    }
    else if(INTCONbits.INT0IF){
        LATA=0x00;
        __delay_ms(10000);
        INTCONbits.INT0IF = 0;  // ??????0???
        return;
    }
  return;
}