#include "setting_hardaware/setting.h"
#include <stdlib.h>
#include "stdio.h"
#include "string.h"
// using namespace std;
#include <xc.h>
#define _XTAL_FREQ 4000000  // ???????__delay_ms() ??

char str[20];
void main(void) 
{
    SYSTEM_Initialize() ;
    TRISA=0x00;
    PORTA=0x00;
    while(1);
    return;
}

void __interrupt(high_priority) Hi_ISR(void)
{
    if (PIR1bits.RCIF) {                    // ????????
        char received = RCREG;              // ? RCREG ????????
        if (received >= '0' && received <= '9') { // ?????????
            unsigned char lampState = received - '0'; // ???????
            PORTA = lampState;             // ??????
            UART_Write(received);          // ????????
        }
        else{
            IPR1bits.RCIP = 0;
        }
    }
}