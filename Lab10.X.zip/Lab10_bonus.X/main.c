#define _XTAL_FREQ 125000  // ???????__delay_ms() ??

#include "setting_hardaware/setting.h"
#include <stdlib.h>
#include "stdio.h"
#include "string.h"
// using namespace std;
#include <xc.h>

char str[20];
void main(void) 
{
    OSCCONbits.IRCF = 0b111;
    
    INTCON2bits.INTEDG0 = 0;  // ????????
    INTCONbits.INT0IF = 0;  // ??????0???
    INTCONbits.GIE = 1;     // ??????
    INTCONbits.INT0IE = 1;  // ??????0 (RB0 ????)
    
    SYSTEM_Initialize() ;
    TRISA=0x00;
    PORTA=0x00;
    TRISB=0x01;
    PORTB=0x00;
    while(1){
        strcpy(str, GetString()); // TODO : GetString() in uart.c
    }
    return;
}
void numcount(unsigned char num);
void __interrupt(high_priority) Hi_ISR(void)
{
    
}