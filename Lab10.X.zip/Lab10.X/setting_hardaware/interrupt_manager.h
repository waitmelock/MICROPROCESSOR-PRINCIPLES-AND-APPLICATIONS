#ifndef _INTERRUPT_MANAGER_H
#define _INTERRUPT_MANAGER_H
void INTERRUPT_Initialize(void);

#endif