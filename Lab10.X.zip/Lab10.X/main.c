#include "setting_hardaware/setting.h"
#include <stdlib.h>
#include "stdio.h"
#include "string.h"
// using namespace std;

#include <xc.h>
#define _XTAL_FREQ 4000000  // ???????__delay_ms() ??

char str[20];
void Mode1(){   // Todo : Mode1
    UART_Write_Text("Advance");
    IPR1bits.RCIP = 1;  
    return;
}
void Mode2(){   // Todo : Mode2 
    UART_Write_Text("bonus");
    return ;
}
void main(void) 
{
    SYSTEM_Initialize() ;
    TRISA=0x00;
    PORTA=0x00;
    while(1) {
        strcpy(str, GetString()); // TODO : GetString() in uart.c
        if(str[0]=='m' && str[1]=='1'){ // Mode1
            Mode1();
            ClearBuffer();
        }
        else if(str[0]=='m' && str[1]=='2'){ // Mode2
            Mode2();
            ClearBuffer();
        }
    }
    return;
}

void __interrupt(high_priority) Hi_ISR(void)
{
    if (PIR1bits.RCIF) {                    // ????????
        char received = RCREG;              // ? RCREG ????????
        if (received >= '0' && received <= '9') { // ?????????
            unsigned char lampState = received - '0'; // ???????
            PORTA = lampState;             // ??????
            UART_Write(received);          // ????????
        }
        else{
            IPR1bits.RCIP = 0;
        }
    }
}